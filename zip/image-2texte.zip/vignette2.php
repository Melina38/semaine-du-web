<section class="composant-vignette2 container">
    <div>
        <div>
          <img src="http://wordpress.test/wp-content/uploads/2025/01/orange.svg" alt="icone de la categorie">
          <h3>81% des violences sexuelles sont incestueuses, commises par de la famille.</h3>
        </div>
    </div>
    <div>
        <div>
          <img src="http://wordpress.test/wp-content/uploads/2025/01/orange.svg" alt="icone de la categorie">
          <h3>81% des violences sexuelles sont incestueuses, commises par de la famille.</h3>
        </div>
    </div>
</section>